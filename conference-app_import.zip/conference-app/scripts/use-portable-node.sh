# Source this file (don't execute it) to use the portable Node install
# for the current terminal session only:
#
#   source scripts/use-portable-node.sh
#
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NODE_BIN="${ROOT_DIR}/.node-portable/bin"

if [ ! -x "${NODE_BIN}/node" ]; then
  echo "Portable Node isn't set up yet. Run: bash scripts/get-portable-node.sh"
  return 1 2>/dev/null || exit 1
fi

export PATH="${NODE_BIN}:${PATH}"
echo "Using portable Node: $(node -v) (this only applies to the current terminal)"
