#!/usr/bin/env bash
# Downloads a standalone Node.js build into ./.node-portable — no system
# install, no package manager, no admin rights needed.
set -euo pipefail

NODE_VERSION="20.17.0"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INSTALL_DIR="${ROOT_DIR}/.node-portable"

OS="$(uname -s)"
ARCH="$(uname -m)"

case "$OS" in
  Linux*)  PLATFORM="linux" ;;
  Darwin*) PLATFORM="darwin" ;;
  *)
    echo "Unsupported OS: $OS"
    echo "On Windows, use scripts/get-portable-node.ps1 instead, or use Docker (see README)."
    exit 1
    ;;
esac

case "$ARCH" in
  x86_64|amd64)   NODE_ARCH="x64" ;;
  arm64|aarch64)  NODE_ARCH="arm64" ;;
  *)
    echo "Unsupported architecture: $ARCH"
    exit 1
    ;;
esac

if [ -x "${INSTALL_DIR}/bin/node" ]; then
  echo "Portable Node already set up at ${INSTALL_DIR}"
  "${INSTALL_DIR}/bin/node" -v
  exit 0
fi

FILENAME="node-v${NODE_VERSION}-${PLATFORM}-${NODE_ARCH}"
URL="https://nodejs.org/dist/v${NODE_VERSION}/${FILENAME}.tar.xz"
TMP_ARCHIVE="$(mktemp -t node-portable-XXXXXX).tar.xz"

echo "Downloading ${URL}"
curl -fL --progress-bar "$URL" -o "$TMP_ARCHIVE"

echo "Extracting..."
TMP_EXTRACT_DIR="$(mktemp -d)"
tar -xf "$TMP_ARCHIVE" -C "$TMP_EXTRACT_DIR"

rm -rf "${INSTALL_DIR}"
mv "${TMP_EXTRACT_DIR}/${FILENAME}" "${INSTALL_DIR}"
rm -rf "$TMP_ARCHIVE" "$TMP_EXTRACT_DIR"

echo ""
echo "Done. Portable Node installed at: ${INSTALL_DIR}"
"${INSTALL_DIR}/bin/node" -v
echo ""
echo "Next, add it to your PATH for this terminal session:"
echo "  source scripts/use-portable-node.sh"
echo "Then install deps and start the app:"
echo "  npm install"
echo "  npx expo start"
