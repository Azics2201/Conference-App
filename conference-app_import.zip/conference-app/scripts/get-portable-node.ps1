# Downloads a standalone Node.js build into .\.node-portable — no system
# install, no admin rights needed.
#
# Usage (PowerShell):
#   .\scripts\get-portable-node.ps1
#   $env:Path = "$PWD\.node-portable;$env:Path"
#   npm install
#   npx expo start

$ErrorActionPreference = "Stop"

$NodeVersion = "20.17.0"
$RootDir = Split-Path -Parent $PSScriptRoot
$InstallDir = Join-Path $RootDir ".node-portable"

$Arch = if ([Environment]::Is64BitOperatingSystem) {
  if ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") { "arm64" } else { "x64" }
} else {
  "x86"
}

if (Test-Path (Join-Path $InstallDir "node.exe")) {
  Write-Host "Portable Node already set up at $InstallDir"
  & (Join-Path $InstallDir "node.exe") -v
  exit 0
}

$FileName = "node-v$NodeVersion-win-$Arch"
$Url = "https://nodejs.org/dist/v$NodeVersion/$FileName.zip"
$TmpZip = Join-Path $env:TEMP "$FileName.zip"
$TmpExtract = Join-Path $env:TEMP "node-portable-extract"

Write-Host "Downloading $Url"
Invoke-WebRequest -Uri $Url -OutFile $TmpZip

Write-Host "Extracting..."
if (Test-Path $TmpExtract) { Remove-Item -Recurse -Force $TmpExtract }
Expand-Archive -Path $TmpZip -DestinationPath $TmpExtract

if (Test-Path $InstallDir) { Remove-Item -Recurse -Force $InstallDir }
Move-Item (Join-Path $TmpExtract $FileName) $InstallDir

Remove-Item -Force $TmpZip
Remove-Item -Recurse -Force $TmpExtract

Write-Host ""
Write-Host "Done. Portable Node installed at: $InstallDir"
& (Join-Path $InstallDir "node.exe") -v
Write-Host ""
Write-Host "Next, add it to PATH for this session:"
Write-Host '  $env:Path = "' -NoNewline
Write-Host "$InstallDir;`$env:Path`""
Write-Host "Then install deps and start the app:"
Write-Host "  npm install"
Write-Host "  npx expo start"
