# TechConnect — Conference Companion App (React Native / Expo prototype)

A working mobile prototype covering the core conference-app requirements:

- **Registration** — a form that collects name, email, org, role, dietary needs, saved on-device (`RegisterScreen`).
- **Registration data management** — stored via `AppContext` + AsyncStorage; swap for a real API later (see below).
- **Program / presentations** — sessions grouped by day, tap through to full session detail (`ProgramScreen`, `SessionDetailScreen`).
- **Speakers** — list + bio + their sessions (`SpeakersScreen`, `SpeakerDetailScreen`).
- **Venue info + map** — address, description, map preview, "Open in Maps" button (`InfoScreen`).
- **Materials / organizational info** — downloadable-document list, same screen as venue.
- **Announcements & notifications** — a feed of updates, plus a local-notification demo so you can see the notify flow without a backend (`AnnouncementsScreen`).

All content (sessions, speakers, venue, materials, announcements) lives in `src/data/*.js` as mock data — replace with real API calls when you're ready.

## Stack

- **Expo (React Native, managed workflow)** — fastest path to a runnable app on iOS/Android/web without native build tooling.
- **React Navigation** (bottom tabs + native stacks) — standard, well-documented navigation.
- **AsyncStorage** — simple on-device persistence for the registration record, favorited sessions, and announcement history.
- **expo-notifications** — schedules a local notification when an announcement is "sent," standing in for a real push-notification backend.

No backend is included — this is a client-only prototype with realistic seams for adding one.

## Project structure

```
conference-app/
  App.js
  app.json
  package.json
  src/
    data/            mock content: event.js, sessions.js, speakers.js, venue.js, materials.js, announcements.js
    context/          AppContext.js — registration, favorites, announcements state + AsyncStorage
    utils/            notifications.js — local notification helper
    navigation/       index.js — bottom tabs + nested stacks
    screens/          Home, Register, Program, SessionDetail, Speakers, SpeakerDetail, Info, Announcements
    components/       SessionCard, SpeakerCard, AnnouncementCard
```

## How to run it

### Option A — Docker (no Node.js install required)

**Prerequisites:** Docker Desktop (or Docker Engine + Compose on Linux), and the **Expo Go** app on your phone.

```bash
cd conference-app
docker compose run --rm --service-ports app
```

This builds the image, installs dependencies inside the container, and starts Expo in **tunnel mode** — so your phone can connect even though it isn't on the same network as the container (this matters especially on macOS/Windows, where Docker's networking is isolated from your LAN).

Wait for the terminal to print a QR code and a `exp://...exp.direct` URL, then scan it with the Expo Go app. First boot is slower (installing deps + starting the tunnel); rebuilds after that are fast since `node_modules` lives in a container-only volume and dependencies are cached.

To stop it, `Ctrl+C`. To rebuild after changing `package.json`, add `--build`:
```bash
docker compose run --rm --build --service-ports app
```

Editing files under `src/` on your host is picked up immediately (the project folder is bind-mounted) — no rebuild needed for code changes, only for dependency changes.

If you'd rather run it detached and just tail the logs for the QR code:
```bash
docker compose up --build
docker compose logs -f
```

### Option B — Standalone Node.js binary (no install, no Docker)

If you'd rather not use Docker, this downloads a portable Node.js build into the project folder — it's not installed system-wide, needs no admin rights, and is easy to delete (`rm -rf .node-portable`) when you're done.

**macOS / Linux:**
```bash
cd conference-app
bash scripts/get-portable-node.sh
source scripts/use-portable-node.sh   # puts node/npm on PATH for this terminal only
npm install
npx expo start
```

**Windows (PowerShell):**
```powershell
cd conference-app
.\scripts\get-portable-node.ps1
$env:Path = "$PWD\.node-portable;$env:Path"
npm install
npx expo start
```

`source scripts/use-portable-node.sh` (or the `$env:Path` line on Windows) only affects your current terminal session — close the terminal and it's gone, nothing is added to your system permanently. Run that line again each time you open a new terminal to work on the project.

Since this runs directly on your machine (not inside a container), your phone can usually connect over plain LAN — no `--tunnel` needed unless your phone and computer are on different networks or a firewall blocks it, in which case run `npx expo start --tunnel` instead.

### Option C — Node.js installed locally

**Prerequisites:** Node.js 18+, npm, and either the **Expo Go** app on your phone (easiest) or an Android/iOS emulator.

```bash
cd conference-app
npm install
npx expo start
```

This opens the Expo developer tools in your terminal/browser with a QR code.

- **On your phone:** install "Expo Go" from the App Store / Play Store, then scan the QR code.
- **On an emulator:** press `a` (Android) or `i` (iOS, macOS only) in the terminal after `expo start`.
- **In a browser (limited):** press `w` — navigation and forms work, but native modules like notifications behave differently on web.

The first launch will ask for notification permissions — accept them to see the "send announcement" demo trigger a real device notification.

## Running in a browser

Because this is an Expo app, the same codebase also runs in a browser via `react-native-web` (already added as a dependency) — no extra setup beyond `npm install`.

- **While `expo start` is already running** (Docker, portable-node, or local-node — any of the three): press `w` in the terminal, and it opens in your default browser.
- **Or start it directly for web:**
  ```bash
  npm run web
  ```
  With Docker, run it as: `docker compose run --rm --service-ports app npx expo start --web`

It uses the same port already exposed in `docker-compose.yml` (`8081`), so no extra port mapping is needed there.

**Things that behave a little differently on web:**
- **Notifications** — the announcement "Send" demo uses the browser's Notification permission prompt instead of a native push, and support varies by browser (Safari in particular is limited). Everything else (registration, program, speakers, venue info) works the same as on a phone.
- **Bottom tab bar** — React Navigation renders it fine, but it's designed for a phone-width screen, so it'll look better in a narrow browser window or with the browser's device-emulation mode than full-width on a desktop monitor.

**If you get a blank white screen on web:** this was an issue with an earlier version of this project — the nested stack navigators used `@react-navigation/native-stack`, which depends on `react-native-screens`, and that library doesn't render on web (it fails silently instead of erroring). Fixed by switching those stacks to the JS-based `@react-navigation/stack` instead, which works identically across web and native. If you pulled an older copy of this project, run `npm install` again to pick up the new dependency (`@react-navigation/stack`, `react-native-gesture-handler`) and restart the dev server.

## Trying it out

1. Open the app → **Home** tab → tap **Register for the conference** → fill the form → submit. The Home screen now shows your registration.
2. Go to **Program** → browse Day 1 / Day 2 sessions → tap one for detail → tap the star to favorite it (persists across restarts).
3. Go to **Speakers** → tap a speaker to see their bio and sessions.
4. Go to **Info** → see venue address, map preview, "Open in Maps," and the materials list (tapping a document opens its URL).
5. Go to **Updates** → tap **"+ Organizer demo: send an announcement"** → fill title/message → Send. It appears at the top of the feed and fires a local push notification.

## What I'd extend first

1. **Real backend for registration & announcements** — a small API (Node/Express, Firebase, or Supabase) so registration data is centrally stored, organizers get a dashboard, and announcements are pushed from the server to everyone's stored Expo push token (real push, not the local-notification stand-in used here).
2. **Per-user notification preferences** — let attendees opt in/out of categories (schedule changes vs. general news) and store an Expo push token against their registration record server-side.
3. **Personal schedule builder** — turn the existing "favorite" sessions into a "My Schedule" view with conflict detection, building on the favorites state already in `AppContext`.
4. **Richer venue map** — swap the static map image for `react-native-maps` with an indoor floor-plan overlay, once you're ready to configure native map keys.
5. **Search & filtering** — filter the program by track/room and search speakers, which becomes more valuable as the session/speaker lists grow.
6. **QR badge / check-in** — generate a QR code on successful registration for fast on-site check-in.
