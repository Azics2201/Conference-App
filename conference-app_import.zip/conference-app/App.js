import 'react-native-gesture-handler';
import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { AppProvider } from './src/context/AppContext';
import RootNavigator from './src/navigation';

export default function App() {
  return (
    <AppProvider>
      <StatusBar style="auto" />
      <RootNavigator />
    </AppProvider>
  );
}
