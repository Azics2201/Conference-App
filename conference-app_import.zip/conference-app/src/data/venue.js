export const VENUE = {
  name: 'Brno Exhibition Centre',
  address: 'Výstaviště 405/1, 603 00 Brno, Czech Republic',
  latitude: 49.1897,
  longitude: 16.5878,
  description: 'The conference takes place in Hall F, with registration in the main lobby from 08:00.',
};
