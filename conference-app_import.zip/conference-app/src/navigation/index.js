import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { Ionicons } from '@expo/vector-icons';

import HomeScreen from '../screens/HomeScreen';
import RegisterScreen from '../screens/RegisterScreen';
import ProgramScreen from '../screens/ProgramScreen';
import SessionDetailScreen from '../screens/SessionDetailScreen';
import SpeakersScreen from '../screens/SpeakersScreen';
import SpeakerDetailScreen from '../screens/SpeakerDetailScreen';
import InfoScreen from '../screens/InfoScreen';
import AnnouncementsScreen from '../screens/AnnouncementsScreen';

const Tab = createBottomTabNavigator();
const HomeStack = createStackNavigator();
const ProgramStack = createStackNavigator();
const SpeakersStack = createStackNavigator();

function HomeStackNavigator() {
  return (
    <HomeStack.Navigator>
      <HomeStack.Screen name="Home" component={HomeScreen} options={{ title: 'TechConnect 2026' }} />
      <HomeStack.Screen name="Register" component={RegisterScreen} options={{ title: 'Register' }} />
    </HomeStack.Navigator>
  );
}

function ProgramStackNavigator() {
  return (
    <ProgramStack.Navigator>
      <ProgramStack.Screen name="Program" component={ProgramScreen} options={{ title: 'Program' }} />
      <ProgramStack.Screen name="SessionDetail" component={SessionDetailScreen} options={{ title: 'Session' }} />
    </ProgramStack.Navigator>
  );
}

function SpeakersStackNavigator() {
  return (
    <SpeakersStack.Navigator>
      <SpeakersStack.Screen name="Speakers" component={SpeakersScreen} options={{ title: 'Speakers' }} />
      <SpeakersStack.Screen name="SpeakerDetail" component={SpeakerDetailScreen} options={{ title: 'Speaker' }} />
    </SpeakersStack.Navigator>
  );
}

const ICONS = {
  HomeTab: 'home-outline',
  ProgramTab: 'calendar-outline',
  SpeakersTab: 'people-outline',
  InfoTab: 'information-circle-outline',
  AnnouncementsTab: 'megaphone-outline',
};

export default function RootNavigator() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarIcon: ({ color, size }) => <Ionicons name={ICONS[route.name]} color={color} size={size} />,
          tabBarActiveTintColor: '#4F46E5',
          tabBarInactiveTintColor: '#9CA3AF',
        })}
      >
        <Tab.Screen name="HomeTab" component={HomeStackNavigator} options={{ title: 'Home' }} />
        <Tab.Screen name="ProgramTab" component={ProgramStackNavigator} options={{ title: 'Program' }} />
        <Tab.Screen name="SpeakersTab" component={SpeakersStackNavigator} options={{ title: 'Speakers' }} />
        <Tab.Screen name="InfoTab" component={InfoScreen} options={{ title: 'Info', headerShown: true }} />
        <Tab.Screen name="AnnouncementsTab" component={AnnouncementsScreen} options={{ title: 'Updates', headerShown: true }} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
