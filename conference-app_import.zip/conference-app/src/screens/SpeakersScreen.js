import React from 'react';
import { FlatList, StyleSheet } from 'react-native';
import { SPEAKERS } from '../data/speakers';
import SpeakerCard from '../components/SpeakerCard';

export default function SpeakersScreen({ navigation }) {
  return (
    <FlatList
      style={styles.container}
      contentContainerStyle={{ padding: 16 }}
      data={SPEAKERS}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <SpeakerCard speaker={item} onPress={() => navigation.navigate('SpeakerDetail', { speakerId: item.id })} />
      )}
    />
  );
}

const styles = StyleSheet.create({ container: { flex: 1, backgroundColor: '#F3F4F6' } });
