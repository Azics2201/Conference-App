import React, { useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, TextInput, Modal } from 'react-native';
import { useApp } from '../context/AppContext';
import AnnouncementCard from '../components/AnnouncementCard';

export default function AnnouncementsScreen() {
  const { announcements, addAnnouncement } = useApp();
  const [modalVisible, setModalVisible] = useState(false);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');

  const onSend = async () => {
    if (!title.trim() || !body.trim()) return;
    await addAnnouncement(title.trim(), body.trim());
    setTitle('');
    setBody('');
    setModalVisible(false);
  };

  return (
    <View style={styles.container}>
      <FlatList
        contentContainerStyle={{ padding: 16 }}
        data={announcements}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <AnnouncementCard announcement={item} />}
        ListHeaderComponent={
          <TouchableOpacity style={styles.demoBtn} onPress={() => setModalVisible(true)}>
            <Text style={styles.demoBtnText}>+ Organizer demo: send an announcement</Text>
          </TouchableOpacity>
        }
      />

      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Send announcement</Text>
            <TextInput style={styles.input} placeholder="Title" value={title} onChangeText={setTitle} />
            <TextInput
              style={[styles.input, { height: 80 }]}
              placeholder="Message"
              value={body}
              onChangeText={setBody}
              multiline
            />
            <Text style={styles.hint}>
              In production this would come from an organizer dashboard via a push notification backend.
            </Text>
            <View style={styles.modalActions}>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Text style={styles.cancel}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={onSend}>
                <Text style={styles.send}>Send</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  demoBtn: { backgroundColor: '#EEF2FF', borderRadius: 10, padding: 12, marginBottom: 14, borderWidth: 1, borderColor: '#C7D2FE', borderStyle: 'dashed' },
  demoBtnText: { color: '#4338CA', fontSize: 13, fontWeight: '600', textAlign: 'center' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: '#fff', borderTopLeftRadius: 16, borderTopRightRadius: 16, padding: 20 },
  modalTitle: { fontSize: 16, fontWeight: '800', marginBottom: 12 },
  input: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14, marginBottom: 10 },
  hint: { fontSize: 11, color: '#9CA3AF', marginBottom: 14 },
  modalActions: { flexDirection: 'row', justifyContent: 'flex-end' },
  cancel: { color: '#6B7280', fontWeight: '600', marginRight: 20 },
  send: { color: '#4F46E5', fontWeight: '700' },
});
