import React from 'react';
import { Text, StyleSheet, ScrollView, TouchableOpacity, Linking, Image } from 'react-native';
import { VENUE } from '../data/venue';
import { MATERIALS } from '../data/materials';
import { Ionicons } from '@expo/vector-icons';

const staticMapUrl = `https://staticmap.openstreetmap.de/staticmap.php?center=${VENUE.latitude},${VENUE.longitude}&zoom=15&size=600x300&markers=${VENUE.latitude},${VENUE.longitude},red-pushpin`;

export default function InfoScreen() {
  const openInMaps = () => {
    const url = `https://www.google.com/maps/search/?api=1&query=${VENUE.latitude},${VENUE.longitude}`;
    Linking.openURL(url);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.sectionHeader}>Venue</Text>
      <Text style={styles.venueName}>{VENUE.name}</Text>
      <Text style={styles.venueAddress}>{VENUE.address}</Text>
      <Text style={styles.venueDescription}>{VENUE.description}</Text>

      <Image source={{ uri: staticMapUrl }} style={styles.map} resizeMode="cover" />

      <TouchableOpacity style={styles.mapsBtn} onPress={openInMaps}>
        <Ionicons name="navigate-outline" size={16} color="#4F46E5" />
        <Text style={styles.mapsBtnText}>Open in Maps</Text>
      </TouchableOpacity>

      <Text style={[styles.sectionHeader, { marginTop: 28 }]}>Materials & Documents</Text>
      {MATERIALS.map((m) => (
        <TouchableOpacity key={m.id} style={styles.materialRow} onPress={() => Linking.openURL(m.url)}>
          <Ionicons name="document-text-outline" size={20} color="#4F46E5" />
          <Text style={styles.materialText}>{m.title}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  sectionHeader: { fontSize: 16, fontWeight: '800', color: '#111827', marginBottom: 8 },
  venueName: { fontSize: 16, fontWeight: '700', color: '#1F2937' },
  venueAddress: { fontSize: 13, color: '#6B7280', marginTop: 2, marginBottom: 8 },
  venueDescription: { fontSize: 13, color: '#374151', marginBottom: 12, lineHeight: 18 },
  map: { width: '100%', height: 200, borderRadius: 12, marginBottom: 12, backgroundColor: '#E5E7EB' },
  mapsBtn: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start' },
  mapsBtnText: { color: '#4F46E5', fontWeight: '600', fontSize: 13, marginLeft: 6 },
  materialRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F9FAFB', borderRadius: 10, padding: 12, marginBottom: 8 },
  materialText: { marginLeft: 10, fontSize: 14, color: '#1F2937' },
});
