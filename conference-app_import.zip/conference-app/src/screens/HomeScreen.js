import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useApp } from '../context/AppContext';
import { EVENT } from '../data/event';
import AnnouncementCard from '../components/AnnouncementCard';

export default function HomeScreen({ navigation }) {
  const { isRegistered, registration, announcements } = useApp();

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.eventName}>{EVENT.name}</Text>
      <Text style={styles.eventMeta}>{EVENT.dates} · {EVENT.location}</Text>
      <Text style={styles.tagline}>{EVENT.tagline}</Text>

      {isRegistered ? (
        <View style={styles.regCard}>
          <Text style={styles.regTitle}>You're registered</Text>
          <Text style={styles.regText}>{registration.fullName} · {registration.email}</Text>
        </View>
      ) : (
        <TouchableOpacity style={styles.ctaCard} onPress={() => navigation.navigate('Register')}>
          <Text style={styles.ctaTitle}>Register for the conference</Text>
          <Text style={styles.ctaSubtitle}>Takes less than a minute</Text>
        </TouchableOpacity>
      )}

      <View style={styles.quickLinks}>
        <QuickLink label="Program" onPress={() => navigation.navigate('ProgramTab')} />
        <QuickLink label="Speakers" onPress={() => navigation.navigate('SpeakersTab')} />
        <QuickLink label="Venue & Info" onPress={() => navigation.navigate('InfoTab')} />
      </View>

      <View style={styles.sectionHeaderRow}>
        <Text style={styles.sectionHeader}>Latest announcements</Text>
        <TouchableOpacity onPress={() => navigation.navigate('AnnouncementsTab')}>
          <Text style={styles.seeAll}>See all</Text>
        </TouchableOpacity>
      </View>
      {announcements.slice(0, 2).map((a) => (
        <AnnouncementCard key={a.id} announcement={a} />
      ))}
    </ScrollView>
  );
}

function QuickLink({ label, onPress }) {
  return (
    <TouchableOpacity style={styles.quickLink} onPress={onPress}>
      <Text style={styles.quickLinkText}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  eventName: { fontSize: 24, fontWeight: '800', color: '#111827' },
  eventMeta: { fontSize: 13, color: '#6B7280', marginTop: 4 },
  tagline: { fontSize: 14, color: '#374151', marginTop: 8, marginBottom: 16 },
  ctaCard: { backgroundColor: '#4F46E5', borderRadius: 14, padding: 16, marginBottom: 16 },
  ctaTitle: { color: '#fff', fontWeight: '700', fontSize: 16 },
  ctaSubtitle: { color: '#E0E7FF', fontSize: 12, marginTop: 4 },
  regCard: { backgroundColor: '#ECFDF5', borderRadius: 14, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: '#A7F3D0' },
  regTitle: { fontWeight: '700', color: '#065F46' },
  regText: { color: '#047857', marginTop: 4, fontSize: 12 },
  quickLinks: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 20 },
  quickLink: { backgroundColor: '#fff', paddingVertical: 10, paddingHorizontal: 14, borderRadius: 10, marginRight: 8, marginBottom: 8 },
  quickLinkText: { color: '#1F2937', fontWeight: '600', fontSize: 13 },
  sectionHeaderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  sectionHeader: { fontSize: 16, fontWeight: '700', color: '#111827' },
  seeAll: { color: '#4F46E5', fontSize: 13, fontWeight: '600' },
});
