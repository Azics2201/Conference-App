import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { useApp } from '../context/AppContext';

const ROLES = ['Attendee', 'Speaker', 'Press', 'Organizer'];

export default function RegisterScreen({ navigation }) {
  const { register } = useApp();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [organization, setOrganization] = useState('');
  const [role, setRole] = useState('Attendee');
  const [dietary, setDietary] = useState('');

  const isValidEmail = /\S+@\S+\.\S+/.test(email);

  const onSubmit = async () => {
    if (!fullName.trim()) return Alert.alert('Missing info', 'Please enter your full name.');
    if (!isValidEmail) return Alert.alert('Missing info', 'Please enter a valid email address.');
    await register({
      fullName: fullName.trim(),
      email: email.trim(),
      organization: organization.trim(),
      role,
      dietary: dietary.trim(),
    });
    Alert.alert("You're registered!", "We'll send updates to your email and to this app.", [
      { text: 'OK', onPress: () => navigation.goBack() },
    ]);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.label}>Full name *</Text>
      <TextInput style={styles.input} value={fullName} onChangeText={setFullName} placeholder="Jane Doe" />

      <Text style={styles.label}>Email *</Text>
      <TextInput
        style={styles.input}
        value={email}
        onChangeText={setEmail}
        placeholder="jane@example.com"
        keyboardType="email-address"
        autoCapitalize="none"
      />

      <Text style={styles.label}>Organization</Text>
      <TextInput style={styles.input} value={organization} onChangeText={setOrganization} placeholder="Company / University" />

      <Text style={styles.label}>Role</Text>
      <View style={styles.chipRow}>
        {ROLES.map((r) => (
          <TouchableOpacity key={r} style={[styles.chip, role === r && styles.chipActive]} onPress={() => setRole(r)}>
            <Text style={[styles.chipText, role === r && styles.chipTextActive]}>{r}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>Dietary requirements</Text>
      <TextInput style={styles.input} value={dietary} onChangeText={setDietary} placeholder="e.g. vegetarian, none" />

      <TouchableOpacity style={styles.submitBtn} onPress={onSubmit}>
        <Text style={styles.submitText}>Complete registration</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  label: { fontSize: 13, fontWeight: '600', color: '#374151', marginBottom: 6, marginTop: 14 },
  input: { borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap' },
  chip: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, backgroundColor: '#F3F4F6', marginRight: 8, marginBottom: 8 },
  chipActive: { backgroundColor: '#4F46E5' },
  chipText: { fontSize: 13, color: '#374151' },
  chipTextActive: { color: '#fff', fontWeight: '600' },
  submitBtn: { backgroundColor: '#4F46E5', borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginTop: 28, marginBottom: 40 },
  submitText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
