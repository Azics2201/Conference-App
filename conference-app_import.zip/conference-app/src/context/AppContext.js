import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { INITIAL_ANNOUNCEMENTS } from '../data/announcements';
import { scheduleLocalNotification } from '../utils/notifications';

const STORAGE_KEYS = {
  REGISTRATION: '@conference/registration',
  FAVORITES: '@conference/favorites',
  ANNOUNCEMENTS: '@conference/announcements',
};

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [registration, setRegistration] = useState(null);
  const [favorites, setFavorites] = useState([]);
  const [announcements, setAnnouncements] = useState(INITIAL_ANNOUNCEMENTS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [regRaw, favRaw, annRaw] = await Promise.all([
          AsyncStorage.getItem(STORAGE_KEYS.REGISTRATION),
          AsyncStorage.getItem(STORAGE_KEYS.FAVORITES),
          AsyncStorage.getItem(STORAGE_KEYS.ANNOUNCEMENTS),
        ]);
        if (regRaw) setRegistration(JSON.parse(regRaw));
        if (favRaw) setFavorites(JSON.parse(favRaw));
        if (annRaw) setAnnouncements(JSON.parse(annRaw));
      } catch (e) {
        console.warn('Failed to load stored data', e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const register = async (data) => {
    const record = { ...data, registeredAt: new Date().toISOString() };
    setRegistration(record);
    await AsyncStorage.setItem(STORAGE_KEYS.REGISTRATION, JSON.stringify(record));
  };

  const clearRegistration = async () => {
    setRegistration(null);
    await AsyncStorage.removeItem(STORAGE_KEYS.REGISTRATION);
  };

  const toggleFavorite = async (sessionId) => {
    setFavorites((prev) => {
      const next = prev.includes(sessionId)
        ? prev.filter((id) => id !== sessionId)
        : [...prev, sessionId];
      AsyncStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(next));
      return next;
    });
  };

  const addAnnouncement = async (title, body, priority = 'normal') => {
    const newItem = {
      id: `a${Date.now()}`,
      title,
      body,
      timestamp: new Date().toISOString(),
      priority,
    };
    setAnnouncements((prev) => {
      const next = [newItem, ...prev];
      AsyncStorage.setItem(STORAGE_KEYS.ANNOUNCEMENTS, JSON.stringify(next));
      return next;
    });
    await scheduleLocalNotification(title, body);
  };

  const value = {
    loading,
    registration,
    isRegistered: !!registration,
    register,
    clearRegistration,
    favorites,
    toggleFavorite,
    announcements,
    addAnnouncement,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
