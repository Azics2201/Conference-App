import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { SPEAKERS } from '../data/speakers';
import { Ionicons } from '@expo/vector-icons';

export default function SessionCard({ session, onPress, isFavorite, onToggleFavorite }) {
  const speakerNames = session.speakerIds
    .map((id) => SPEAKERS.find((s) => s.id === id)?.name)
    .filter(Boolean)
    .join(', ');

  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <View style={styles.timeCol}>
        <Text style={styles.time}>{session.startTime}</Text>
        <Text style={styles.timeEnd}>{session.endTime}</Text>
      </View>
      <View style={styles.body}>
        <View style={styles.titleRow}>
          <Text style={styles.title} numberOfLines={2}>{session.title}</Text>
          {onToggleFavorite && (
            <TouchableOpacity onPress={onToggleFavorite} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Ionicons
                name={isFavorite ? 'star' : 'star-outline'}
                size={20}
                color={isFavorite ? '#E8A93A' : '#9AA0A6'}
              />
            </TouchableOpacity>
          )}
        </View>
        <Text style={styles.meta}>{session.room} · {session.track}</Text>
        {!!speakerNames && <Text style={styles.speakers}>{speakerNames}</Text>}
        {session.updatedAt && (
          <View style={styles.changedBadge}>
            <Text style={styles.changedText}>Updated</Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  timeCol: { width: 56, marginRight: 12 },
  time: { fontWeight: '700', fontSize: 13, color: '#1F2937' },
  timeEnd: { fontSize: 12, color: '#9AA0A6' },
  body: { flex: 1 },
  titleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  title: { fontSize: 15, fontWeight: '600', color: '#1F2937', flex: 1, marginRight: 8 },
  meta: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  speakers: { fontSize: 12, color: '#4B5563', marginTop: 4, fontStyle: 'italic' },
  changedBadge: { marginTop: 6, alignSelf: 'flex-start', backgroundColor: '#FEF3C7', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  changedText: { fontSize: 10, color: '#92400E', fontWeight: '700' },
});
