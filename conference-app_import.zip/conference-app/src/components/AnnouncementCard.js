import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

function timeAgo(iso) {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}

export default function AnnouncementCard({ announcement }) {
  const isHigh = announcement.priority === 'high';
  return (
    <View style={[styles.card, isHigh && styles.cardHigh]}>
      <View style={styles.headerRow}>
        <Text style={styles.title}>{announcement.title}</Text>
        <Text style={styles.time}>{timeAgo(announcement.timestamp)}</Text>
      </View>
      <Text style={styles.body}>{announcement.body}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: '#fff', borderRadius: 12, padding: 14, marginBottom: 10, borderLeftWidth: 4, borderLeftColor: '#4F46E5' },
  cardHigh: { borderLeftColor: '#DC2626' },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  title: { fontSize: 15, fontWeight: '700', color: '#1F2937', flex: 1, marginRight: 8 },
  time: { fontSize: 11, color: '#9CA3AF' },
  body: { fontSize: 13, color: '#4B5563', lineHeight: 18 },
});
